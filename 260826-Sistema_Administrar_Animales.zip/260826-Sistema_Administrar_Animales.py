class Animal:

    def __init__(self, nombre, edad, especie):
        self.nombre = nombre
        self.especie = especie
        self.__edad = edad 

    def get_edad(self):
        return self.__edad

    def set_edad(self, nueva_edad):
        if nueva_edad >= 0:
            self.__edad = nueva_edad
        else:
            print("Error: No se permiten edades negativas.")        

    def hacer_sonido(self):
        print("Este animal hace un sonido")

    def describir(self):
        print(
            f"Nombre: {self.nombre}, Edad: {self.get_edad()}, Especie: {self.especie}"
        )

class Perro(Animal):

    def __init__(self, nombre, edad):
        super().__init__(nombre, edad, especie="Perro")

    def hacer_sonido(self):
        print("Guau")

    def correr(self):
        print(f"{self.nombre} está corriendo alegremente.")

class Gato(Animal):

    def __init__(self, nombre, edad):
        super().__init__(nombre, edad, especie="Gato")

    def hacer_sonido(self):
        print("Miau")

    def maullar(self):
        print(f"{self.nombre} está maullando suavemente.")

class Pajaro(Animal):

    def __init__(self, nombre, edad):
        super().__init__(nombre, edad, especie="Pájaro")

    def hacer_sonido(self):
        print("Pío")

    def volar(self):
        print(f"{self.nombre} está volando libremente.")

if __name__ == "__main__":
    animales = [
        Perro("Kratos", 5),
        Gato("Mia", 3),
        Pajaro("Liu", 1),
    ]

    print("--- Datos Interesantes de Nuestros Animales ---")
    for animal in animales:
        animal.describir()
        animal.hacer_sonido()
        print("-" * 30)

    print("\n--- Acciones que Realizaron Nuestros Aniamles ---")
    animales[0].correr()
    print("\n")
    animales[1].maullar()
    print("\n")
    animales[2].volar()
    print("-" * 30)